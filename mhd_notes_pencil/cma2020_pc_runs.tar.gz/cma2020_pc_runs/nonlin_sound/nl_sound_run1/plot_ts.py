#!/usr/bin/env python

import pencil as pc
import pylab as P

ts=pc.read_ts(plot_data=False)

tt=ts.t
ethm=ts.ethm
ekin=ts.ekin
etot=ethm+ekin

print 'total energy:%9.2e'%etot.mean()
rap=(etot.max()-etot.min())/etot.mean()
print 'rel error or total energy:%9.2e'%rap
print 'last time:%5.2f'%tt[-1]

P.plot(tt,etot,label='etot')
P.plot(tt,ethm,label='ethm')
P.plot(tt,ekin,label='ekin')
P.legend(loc='best')
P.xlabel('time')
P.title('Nonlinear sound waves: energies evolution')
P.show()

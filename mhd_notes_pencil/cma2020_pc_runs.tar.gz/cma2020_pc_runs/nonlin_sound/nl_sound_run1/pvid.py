#!/usr/bin/env python

import numpy as N
import pylab as P
import pencil as pc

f, t = pc.read_slices(field='uu1', proc=0)

dim=pc.read_dim()
par=pc.read_param(quiet=True)
par2=pc.read_param(quiet=True, param2=True)
grid=pc.read_grid(param=par, quiet=True)
nt=len(t)
ff=f.reshape(nt, dim.nx)

P.ion()
P.subplot(211)
line, = P.plot(ff[0, :])
P.xlim(xmax=dim.nx-1)
st=P.figtext(0.8, 0.85, 't=%.1f'%t[0])

for i in range(1, nt):
  line.set_ydata(ff[i, :])
  st.set_text('t=%.1f'%t[i])
  P.draw()
P.plot(ff[i, :],'o')
P.xlim(xmax=dim.nx-1)
P.xlabel('$x$')
Re_grid=par.ampluu[0]*grid.dx/par2.nu
P.title('ampli=%9.2e  visc=%9.2e  Re_grid=%9.2e'%(par.ampluu[0], par2.nu, Re_grid))

P.subplot(212)
frame = 0, dim.nx-1, t[0], t[-1]
P.imshow(ff, origin='lower', extent=frame, aspect='auto')
P.xlabel('$x$')
P.ylabel('time')
P.show()

